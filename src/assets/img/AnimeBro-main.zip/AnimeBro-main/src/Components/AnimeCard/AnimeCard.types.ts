export interface AnimeCardProps {
  image: string;
  title: string;
  code: string | undefined ;
}
