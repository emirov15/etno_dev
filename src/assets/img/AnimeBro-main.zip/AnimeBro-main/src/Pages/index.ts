export * from './HomePage/HomePage';
export * from './AnimeListPage/AnimeListPage';
export * from './AnimeDetailPages/AnimeDetailPages';
export * from './LastChange/LastChange'
export * from './Schedule/Schedule'